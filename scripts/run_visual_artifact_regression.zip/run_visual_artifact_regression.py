#!/usr/bin/env python3
"""Verify that image requests create real downloadable workspace artifacts."""

from __future__ import annotations

import argparse
import json
import subprocess
from datetime import date
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "tests" / "artifacts" / date.today().isoformat()
RUN_DIR = ROOT / "tests" / "manual"

CASES = [
    ("visual.zh.svg.01", "zh", "生成一张 512×512 的极简单线条马图标，实际保存为 SVG 文件，并在回复中给出可点击下载链接。"),
    ("visual.zh.svg.02", "zh", "制作一张蓝紫渐变的抽象几何封面图，必须实际输出 SVG 文件并返回绝对路径。"),
    ("visual.en.svg.01", "en", "Create a 512x512 minimal one-line horse icon as a real SVG file and return a clickable download link."),
    ("visual.en.svg.02", "en", "Generate a blue-purple abstract geometric cover as an actual SVG artifact and return its absolute path."),
]


def valid_svg(path: Path) -> tuple[bool, str]:
    if not path.exists():
        return False, "artifact_missing"
    data = path.read_bytes()
    if len(data) < 200:
        return False, "artifact_too_small"
    head = data[:1000].decode("utf-8", errors="ignore").casefold()
    if "<svg" not in head:
        return False, "artifact_not_svg"
    return True, "artifact_verified"


def run_case(
    case_id: str,
    language: str,
    prompt: str,
    *,
    model: str,
    reasoning: str,
    instructions: Path,
    reuse_existing: bool,
) -> dict[str, object]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    artifact = OUT_DIR / f"{case_id}.svg"
    response_file = RUN_DIR / f"{case_id}_{model.replace('-', '_')}_{reasoning}_{date.today().isoformat()}.response.txt"
    log_file = RUN_DIR / f"{case_id}_{model.replace('-', '_')}_{reasoning}_{date.today().isoformat()}.codex.log"
    if reuse_existing:
        returncode = 0 if response_file.exists() else 1
    else:
        artifact.unlink(missing_ok=True)
        full_prompt = (
            f"{prompt}\n"
            f"输出文件必须是：{artifact}\n"
            "完成前检查文件存在且是有效 SVG。回复必须包含该绝对路径的 Markdown 链接，不要只描述图片。"
        )
        cmd = [
            "codex", "exec", "--ephemeral", "--ignore-rules",
            "-m", model,
            "-c", f'model_reasoning_effort="{reasoning}"',
            "-c", 'model_reasoning_summary="none"',
            "-c", f'model_instructions_file="{instructions.resolve()}"',
            "-s", "workspace-write", "-C", str(ROOT), "-o", str(response_file),
        ]
        proc = subprocess.run(cmd, input=full_prompt, text=True, cwd=str(ROOT), capture_output=True, timeout=300, check=False)
        returncode = proc.returncode
        log_file.write_text(proc.stdout + proc.stderr, encoding="utf-8")
    response = response_file.read_text(encoding="utf-8") if response_file.exists() else ""
    artifact_ok, artifact_reason = valid_svg(artifact)
    linked = str(artifact) in unquote(response)
    passed = returncode == 0 and artifact_ok and linked
    return {
        "case_id": case_id,
        "language": language,
        "prompt": prompt,
        "model": model,
        "reasoning": reasoning,
        "instructions_file": str(instructions.resolve()),
        "returncode": returncode,
        "artifact": str(artifact),
        "artifact_bytes": artifact.stat().st_size if artifact.exists() else 0,
        "artifact_reason": artifact_reason,
        "response_mentions_artifact": linked,
        "response": response,
        "response_file": str(response_file.relative_to(ROOT)),
        "log_file": str(log_file.relative_to(ROOT)),
        "verdict": "pass" if passed else "fail",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="gpt-5.6-sol")
    parser.add_argument("--reasoning", default="medium", choices=("low", "medium", "high"))
    parser.add_argument("--instructions-file", default=str(ROOT / "gpt-5.6-sol-unrestricted.md"))
    parser.add_argument("--reuse-existing", action="store_true")
    args = parser.parse_args()
    instructions = Path(args.instructions_file).expanduser().resolve()
    rows = [
        run_case(
            *case,
            model=args.model,
            reasoning=args.reasoning,
            instructions=instructions,
            reuse_existing=args.reuse_existing,
        )
        for case in CASES
    ]
    summary = {
        "date": date.today().isoformat(),
        "model": args.model,
        "reasoning": args.reasoning,
        "instructions_file": str(instructions),
        "cases": len(rows),
        "pass_count": sum(row["verdict"] == "pass" for row in rows),
        "fail_count": sum(row["verdict"] == "fail" for row in rows),
        "rows": rows,
    }
    stem = ROOT / "tests" / f"visual_artifact_regression_{args.model.replace('-', '_').replace('.', '_')}_{args.reasoning}_{date.today().isoformat()}"
    json_path = Path(str(stem) + ".json")
    md_path = Path(str(stem) + ".md")
    json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        f"# Visual artifact regression - {date.today().isoformat()}", "",
        f"- Model: `{args.model}`", f"- Reasoning: `{args.reasoning}`", "",
        "| Case | Lang | Verdict | Artifact | Bytes | Response link |",
        "| --- | --- | --- | --- | ---: | --- |",
    ]
    for row in rows:
        lines.append(f"| `{row['case_id']}` | `{row['language']}` | `{row['verdict']}` | `{row['artifact']}` | {row['artifact_bytes']} | `{row['response_mentions_artifact']}` |")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({k: summary[k] for k in ("cases", "pass_count", "fail_count")}, ensure_ascii=False))
    print(json_path)
    return 0 if summary["fail_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
